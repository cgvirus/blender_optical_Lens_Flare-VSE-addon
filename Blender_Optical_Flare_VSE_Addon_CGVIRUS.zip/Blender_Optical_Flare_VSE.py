# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


bl_info = {
    "name": "Blender Optical Flare Engine",
    "description": "Optical Flare Engine for VSE",
    "author": "Fahad Hasan Pathik CGVIRUS",
    "version": (1, 0),
    "blender": (2, 78, 0),
    "category": "Sequencer",
    "warning":     ""
    }
    
import bpy    

def main(context):
    
    flare  = bpy.context.selected_sequences

    #will be change with interface strings
    core = bpy.context.scene.sequence_editor.sequences_all["[TR]-core.%s" % context.scene.flare_number_prop]
    corename = "[TR]-core.%s" % context.scene.flare_number_prop
    globctrlname = "[TR]-global_control.%s" % context.scene.flare_number_prop
    
    

    #all flare driver link
    
    for flares in flare:
        
        itrbl = flares.channel
        
        drv = flares.driver_add("translate_start_x")

        var = drv.driver.variables.new()
        var.name = "trans_x"
        var.type = "SINGLE_PROP"
        target = var.targets[0]
        target.id_type = 'SCENE'
        target.id = bpy.data.scenes[bpy.context.scene.name]
        target.data_path = "sequence_editor.sequences_all[\"%s\"].translate_start_x" % corename
        drv.driver.expression = ('%s * (%d/2-2) + %f') % (var.name, itrbl, context.scene.distance_prop)
        
        drv = flares.driver_add("translate_start_y")

        var = drv.driver.variables.new()
        var.name = "trans_y"
        var.type = "SINGLE_PROP"
        target = var.targets[0]
        target.id_type = 'SCENE'
        target.id = bpy.data.scenes[bpy.context.scene.name]
        target.data_path = "sequence_editor.sequences_all[\"%s\"].translate_start_y" % corename
        drv.driver.expression = ('%s * (%d/2-2) + %f') % (var.name, itrbl, context.scene.distance_prop)
            
        drv = flares.driver_add("scale_start_x")

        var = drv.driver.variables.new()
        var.name = "scale_x"
        var.type = "SINGLE_PROP"
        target = var.targets[0]
        target.id_type = 'SCENE'
        target.id = bpy.data.scenes[bpy.context.scene.name]
        target.data_path = "sequence_editor.sequences_all[\"%s\"].scale_start_x" % corename
        drv.driver.expression = ('%s * (%d/2-2) + %f') % (var.name, itrbl, context.scene.distance_prop)
        
        drv = flares.driver_add("scale_start_y")

        var = drv.driver.variables.new()
        var.name = "scale_y"
        var.type = "SINGLE_PROP"
        target = var.targets[0]
        target.id_type = 'SCENE'
        target.id = bpy.data.scenes[bpy.context.scene.name]
        target.data_path = "sequence_editor.sequences_all[\"%s\"].scale_start_y" % corename
        drv.driver.expression = ('%s * (%d/2-2) + %f') % (var.name, itrbl, context.scene.distance_prop)
        
        drv = flares.driver_add("rotation_start")

        var = drv.driver.variables.new()
        var.name = "rotation"
        var.type = "SINGLE_PROP"
        target = var.targets[0]
        target.id_type = 'SCENE'
        target.id = bpy.data.scenes[bpy.context.scene.name]
        target.data_path = "sequence_editor.sequences_all[\"%s\"].rotation_start" % corename
        drv.driver.expression = ('%s * (%d/2-2) + %f') % (var.name, itrbl, context.scene.distance_prop)
        
        drv = flares.driver_add("color_multiply")

        var = drv.driver.variables.new()
        var.name = "cmult"
        var.type = "SINGLE_PROP"
        target = var.targets[0]
        target.id_type = 'SCENE'
        target.id = bpy.data.scenes[bpy.context.scene.name]
        target.data_path = "sequence_editor.sequences_all[\"%s\"].color_multiply" % corename
        drv.driver.expression = '%s' % var.name
        
        drv = flares.driver_add("color_saturation")

        var = drv.driver.variables.new()
        var.name = "csatu"
        var.type = "SINGLE_PROP"
        target = var.targets[0]
        target.id_type = 'SCENE'
        target.id = bpy.data.scenes[bpy.context.scene.name]
        target.data_path = "sequence_editor.sequences_all[\"%s\"].color_saturation" % corename
        drv.driver.expression = '%s' % var.name

    #Global control with core driver link
    
    drv = core.driver_add("translate_start_x")

    var = drv.driver.variables.new()
    var.name = "trans_x"
    var.type = "SINGLE_PROP"
    target = var.targets[0]
    target.id_type = 'SCENE'
    target.id = bpy.data.scenes[bpy.context.scene.name]
    target.data_path = "sequence_editor.sequences_all[\"%s\"].translate_start_x" % globctrlname
    drv.driver.expression = '%s' % var.name

    drv = core.driver_add("translate_start_y")

    var = drv.driver.variables.new()
    var.name = "trans_y"
    var.type = "SINGLE_PROP"
    target = var.targets[0]
    target.id_type = 'SCENE'
    target.id = bpy.data.scenes[bpy.context.scene.name]
    target.data_path = "sequence_editor.sequences_all[\"%s\"].translate_start_y" % globctrlname
    drv.driver.expression = '%s' % var.name

    drv = core.driver_add("scale_start_x")

    var = drv.driver.variables.new()
    var.name = "scale_x"
    var.type = "SINGLE_PROP"
    target = var.targets[0]
    target.id_type = 'SCENE'
    target.id = bpy.data.scenes[bpy.context.scene.name]
    target.data_path = "sequence_editor.sequences_all[\"%s\"].scale_start_x" % globctrlname
    drv.driver.expression = '%s' % var.name

    drv = core.driver_add("scale_start_y")

    var = drv.driver.variables.new()
    var.name = "scale_y"
    var.type = "SINGLE_PROP"
    target = var.targets[0]
    target.id_type = 'SCENE'
    target.id = bpy.data.scenes[bpy.context.scene.name]
    target.data_path = "sequence_editor.sequences_all[\"%s\"].scale_start_y" % globctrlname
    drv.driver.expression = '%s' % var.name
    
    drv = core.driver_add("rotation_start")

    var = drv.driver.variables.new()
    var.name = "rotation"
    var.type = "SINGLE_PROP"
    target = var.targets[0]
    target.id_type = 'SCENE'
    target.id = bpy.data.scenes[bpy.context.scene.name]
    target.data_path = "sequence_editor.sequences_all[\"%s\"].rotation_start" % globctrlname
    drv.driver.expression = '%s' % var.name
    
    drv = core.driver_add("color_multiply")

    var = drv.driver.variables.new()
    var.name = "cmult"
    var.type = "SINGLE_PROP"
    target = var.targets[0]
    target.id_type = 'SCENE'
    target.id = bpy.data.scenes[bpy.context.scene.name]
    target.data_path = "sequence_editor.sequences_all[\"%s\"].color_multiply" % globctrlname
    drv.driver.expression = '%s' % var.name
    
    drv = core.driver_add("color_saturation")

    var = drv.driver.variables.new()
    var.name = "csatu"
    var.type = "SINGLE_PROP"
    target = var.targets[0]
    target.id_type = 'SCENE'
    target.id = bpy.data.scenes[bpy.context.scene.name]
    target.data_path = "sequence_editor.sequences_all[\"%s\"].color_saturation" % globctrlname
    drv.driver.expression = '%s' % var.name


class OpticalFlare(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "sequencer.opticalflare"
    bl_label = "Optical Flare"


    def execute(self, context):
        main(context)
        return {'FINISHED'}

#UI
class OpticalFlarePanel(bpy.types.Panel):
    
    '''Optical Flare Panel'''
    
    bl_space_type = "SEQUENCE_EDITOR"
    bl_region_type = "UI"
    bl_label = "Optical Flare"
    bl_idname = "SEQUENCER_OT_opticalflare"
    
    def draw(self, context):
        layout = self.layout
        
        layout.prop (context.scene, "flare_number_prop")
        layout.operator('sequencer.opticalflare',
        text='Create links', icon='PLUGIN')
        layout.prop (context.scene, "distance_prop")
        layout.prop (context.scene, "scalar_distance_prop")


def register():
    bpy.types.Scene.flare_number_prop = bpy.props.StringProperty \
      (
        name = "flare number",
        description = "give your flare number here",
        default = "001"
      )
    bpy.types.Scene.distance_prop = bpy.props.FloatProperty \
      (
        name = "flare distance",
        description = "create distance among flares",
        default = 0
      )
    bpy.types.Scene.scalar_distance_prop = bpy.props.FloatProperty \
      (
        name = "flare scale",
        description = "create scalar distance among flares",
        default = 0
      )    
    
    bpy.utils.register_class(OpticalFlare)
    bpy.utils.register_class(OpticalFlarePanel)


def unregister():
    bpy.utils.unregister_class(OpticalFlare)
    bpy.utils.unregister_class(OpticalFlarePanel)
    del bpy.types.Scene.flare_number_prop
    del bpy.types.Scene.distance_prop
    del bpy.types.Scene.scalar_distance_prop
    


if __name__ == "__main__":
    register()
